﻿/*
 * Author	JO Hyeong-Ryeol
 * Since	2013.07.17
 * 
 * This file is a part of the Nicenis project.
 * https://nicenis.codeplex.com
 * 
 * Copyright (C) 2013 JO Hyeong-Ryeol. All rights reserved.
 */

using Nicenis.Windows;

namespace DragSourceSample
{
    /// <summary>
    /// A sample data context that implements the IDataObjectProvider interface.
    /// </summary>
    public class SampleDataContext : IDataObjectProvider
    {
        public object GetDataObject()
        {
            return "Test Data";
        }
    }
}
