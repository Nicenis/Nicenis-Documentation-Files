﻿/*
 * Author	JO Hyeong-Ryeol
 * Since	2013.07.21
 * 
 * This file is a part of the Nicenis project.
 * https://nicenis.codeplex.com
 * 
 * Copyright (C) 2013 JO Hyeong-Ryeol. All rights reserved.
 */

using System.Windows;

namespace DropTargetSample
{
    /// <summary>
    /// The App.
    /// </summary>
    public partial class App : Application
    {
    }
}
