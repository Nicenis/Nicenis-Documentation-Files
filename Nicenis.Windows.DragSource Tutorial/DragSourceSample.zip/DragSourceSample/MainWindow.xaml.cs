﻿/*
 * Author	JO Hyeong-Ryeol
 * Since	2013.07.14
 * 
 * This file is a part of the Nicenis project.
 * https://nicenis.codeplex.com
 * 
 * Copyright (C) 2013 JO Hyeong-Ryeol. All rights reserved.
 */

using System.Windows;

namespace DragSourceSample
{
    /// <summary>
    /// The Nicenis sample window.
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
